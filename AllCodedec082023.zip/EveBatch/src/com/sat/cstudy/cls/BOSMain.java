package com.sat.cstudy.cls;

import java.util.Calendar;
import java.util.Scanner;

public class BOSMain {
	public static void main(String[] args) {
		burgerOrderSystem();
	}

	public static void burgerOrderSystem() {
		String cname = "";
		String mob = "";
		double vBur = 120.0;
		double nBur = 210.0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter your name");
		cname = scan.nextLine();
		System.out.println("Enter your mobile no.");
		mob = scan.nextLine();
		if (mob.length() > 10) {
			System.out.println("You are not qualified to place order with this no.");
			System.exit(0);
		} else {
			System.err.println("\t\t.......Burger Ordering System..........");
			System.out.println("Enter v to order veg burger n to order non veg burger");
			String ch = scan.nextLine().toUpperCase();
			switch (ch) {
			case "V":
				vegOrder(cname, mob, vBur, scan, ch);
				break;
			case "N":
				nonVegOrder(cname, mob, nBur, scan, ch);
				break;

			default:
				System.out.println("Invalid choice");
				break;
			}
		}
	}

	public static void nonVegOrder(String cname, String mob, double nBur, Scanner scan, String ch) {
		System.out.println("Your order for non-veg burger will be with you shortly");
		System.out.println("Enter the no of nveg burgers you wish to order");
		int q1 = scan.nextInt();
		prnBill(cname, q1, nBur, mob, ch);
	}

	public static void vegOrder(String cname, String mob, double vBur, Scanner scan, String ch) {
		System.out.println("Your order for veg burger will be with you shortly");
		System.out.println("Enter the no of burgers you wish to order");
		int q = scan.nextInt();
		prnBill(cname, q, vBur, mob, ch);
	}

	private static void prnBill(String n, int a, double b, String m, String h) {
		Calendar cal = Calendar.getInstance();
		System.err.println("\t\t\tDigital Bill From Burger Ordering System:");
		if (h.equals("V")) {
			System.out.println("\t\t\tYou have ordered for a veg burger");
		}
		if (h.equals("N")) {
			System.out.println("\t\t\tYou have ordered for a nonveg burger");
		}
		System.out.println("\t\t\tMr/Ms " + n + " " + "Your billing details are as under:");
		System.out.println("\t\t\t" + cal.getTime().toLocaleString());
		System.out.println("\t\t\tPlease pay an amount of Rs." + (a * b));
		System.out.println("\t\t\tA copy of the bill has been sent to your mobile " + m);
		System.out.println("\t\t\tThanks for the order please wait for the delivery");
	}

}
