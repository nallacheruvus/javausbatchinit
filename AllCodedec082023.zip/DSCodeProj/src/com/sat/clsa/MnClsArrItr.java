package com.sat.clsa;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

public class MnClsArrItr {
	public static void main(String[] args) {
		Vector<String> vec=new Vector<String>();
		String[] arr2= {"Physics","Nuclear Physics","Dynamics","Fluid Mechanics","Statics"};
		for(String j:arr2) {
			vec.add(j);
		}
		Iterator<String> itra=vec.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next());
		}
		ArrayList<Integer> al=new ArrayList<Integer>();
		int[] arr= {12,13,14,15,16};
		for(int i:arr) {
			al.add(i);
		}
//		Iterator<Integer> itrb=al.iterator();
//		while(itrb.hasNext()) {
//			System.out.println(itrb.next());
//		}
		ListIterator<Integer> lia= al.listIterator();
		while(lia.hasNext()) {
			System.out.println(lia.next());
		}
		System.out.println("_".repeat(30));
		while(lia.hasPrevious()) {
			System.out.println(lia.previous());
		}
		List llc=al.subList(0, 3);
		Iterator<Integer> lla=llc.iterator();
		while(lla.hasNext()) {
			System.out.println(lla.next());
		}
		
		
		
		
	}

}
