package com.sat.clsa;

import java.awt.FlowLayout;

public class TestCls {

	public static void main(String[] args) {

		MainFr fr=new MainFr();
		fr.setDefaultCloseOperation(2);
		fr.setVisible(true);
		fr.setSize(500, 500);
		fr.setLayout(new FlowLayout());
		
		
	}

}
