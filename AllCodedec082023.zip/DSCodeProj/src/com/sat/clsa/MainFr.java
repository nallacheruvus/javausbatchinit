package com.sat.clsa;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MainFr extends JFrame {
	public MainFr() {
		Container cont=this.getContentPane();
		String a[]= {"Red","Green","Blue","Yellow","Orange"};
		Stack<String> vec=new Stack<String>();
		for(String k:a) {
			vec.add(k);
		}
		final JComboBox<String> myBox=new JComboBox<String>(vec);
		cont.add(myBox);
		myBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, myBox.getSelectedItem().toString());
			}
		});
	}
}
