package com.sat.clsa;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.function.Consumer;



public class MnClsStkItr {
	public static void main(String[] args) {
		Stack<Integer> stk=new Stack<Integer>();
		int[] arr= {21,23,24,25,65,76};
		for(int i:arr) {
			stk.push(i);
		}
		Iterator itr=stk.iterator();
		while(itr.hasNext()) {
//			System.out.println(itr.next());
			System.out.println(stk.pop());
		}
		Stack<String> stka=new Stack<String>();
		String[] arr2= {"Physics","Nuclear Physics","Dynamics","Fluid Mechanics","Statics"};
		for(String j:arr2) {
			stka.push(j);
		}
		Iterator<String> itra=stka.iterator();
//		while(itra.hasNext()) {
//			System.out.println(stka.pop());
//		}
		System.out.println("****"+stka.elementAt(0));
		System.out.println("****"+stka.elementAt(1));
//		itra.forEachRemaining(new Consumer<String>() {
//			@Override
//			public void accept(String t) {
//				System.out.println(t);
//			}
//		});
	}

}
