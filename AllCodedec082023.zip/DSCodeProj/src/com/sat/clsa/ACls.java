package com.sat.clsa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class ACls {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/thalesdb", "root", "admin");
			Vector<Logns> al=new Vector<Logns>();
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from logins");
			while(rs.next()) {
				Logns ll=new Logns();
				ll.setUsername(rs.getString(1));
				ll.setPasswords(rs.getString(2));
				al.add(ll);
			}
		
			Iterator<Logns> itr=al.iterator();
			while(itr.hasNext()) {
				Logns l=(Logns)itr.next();
				System.out.println(l.getUsername()+" "+l.getPasswords());
			}
	}

}
