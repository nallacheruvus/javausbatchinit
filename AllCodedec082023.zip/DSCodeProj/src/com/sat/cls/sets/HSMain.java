package com.sat.cls.sets;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class HSMain {
	public static void main(String[] args) {
		HashSet<Integer> hsa=new HashSet<Integer>();
		int[] arr1= {66,6,66,9,9,77,77,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,6,6,6,6};
		for(int a:arr1) {
			hsa.add(a);
		}
		Iterator<Integer> itra=hsa.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next());
		}
		HashSet<Float> hsb=new HashSet<Float>();
		float[] arr2= {88,88,1.1f,2.1f,2.1f,5.4f,7.66666f,7.66666f,7.66666f,7.66666f,66};
		for(float f:arr2) {
			hsb.add(f);
		}
		for(Object o:hsb) {
			System.out.println(o);
		}
		HashSet<Double> hsc=new HashSet<Double>();
		double[] arr3= {21.22,21.22,323.333,323,323,43,43,87.8888,87.8888,90.999,90.999};
		for(double a:arr3) {
			hsc.add(a);
		}
		for(Object o:hsc) {
			System.out.println(o);
		}
		HashSet<Character> hsd=new HashSet<Character>();
		char[] arr4= {'a','a','i','i','i','e','e','u','u','o','o','o'};
		for(char c:arr4) {
			hsd.add(c);
		}
		Iterator<Character> itrb=hsd.iterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}
		String[] arr5= {"Satish","satish","Sakshi","sakshi","junaid","abbas","abbas","lily","lily"};
		HashSet<String> hse=new HashSet<String>();
		for(String j:arr5) {
			hse.add(j.toLowerCase());
		}
		Iterator<String> itrc=hse.iterator();
		while(itrc.hasNext()) {
			System.out.println(itrc.next());
		}
	}

}
