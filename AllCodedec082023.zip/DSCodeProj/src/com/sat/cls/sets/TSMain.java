package com.sat.cls.sets;

import java.util.Iterator;
import java.util.Queue;
import java.util.TreeSet;


public class TSMain {
	public static void main(String[] args) {
		int[] arr1= {10,10,10,10,8,9,9,9,7,2,2,1,1,3,3,5,5,6,6,7,4,4};
		TreeSet<Integer> tsa=new TreeSet<Integer>();
		for(int i:arr1) {
			tsa.add(i);
		}
		Iterator<Integer> itra=tsa.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next());
		}
		float[] arr21= {88,88,1.1f,2.1f,2.1f,5.4f,7.66666f,7.66666f,7.66666f,7.66666f,66};
		TreeSet<Float> tsb=new TreeSet<Float>();
		for(float f:arr21) {
			tsb.add(f);
		}
		for(Object a:tsb) {
			System.out.println(a);
		}
		double[] arr22= {1.2,1.2,3.2,3.2,5.4,5.4,0.1,0.1};
		TreeSet<Double> tsc=new TreeSet<Double>();
		for(double d:arr22) {
			tsc.add(d);
		}
		for(Object b:tsc) {
			System.out.println(b);
		}
		char[] arr23= {'z','z','c','c','c','d','d','e','i','i','u','u'};
		TreeSet<Character> tsd=new TreeSet<Character>();
		for(char c:arr23) {
			tsd.add(c);
		}
		System.out.println("_".repeat(40));
		Iterator<Character> itrd=tsd.iterator();
		while(itrd.hasNext()) {
			System.out.println(itrd.next());
		}
		System.out.println("_".repeat(40));
		Iterator<Character> itre=tsd.descendingIterator();
		while(itre.hasNext()) {
			System.out.println(itre.next());
		}
		System.out.println("_".repeat(40));
		String[] arr5= {"Satish","satish","Sakshi","sakshi","junaid","abbas","abbas","lily","lily"};
		TreeSet<String> tsf=new TreeSet<String>();
		for(String j:arr5) {
			tsf.add(j.toLowerCase());
		}
		Iterator<String> itrg=tsf.iterator();
		while(itrg.hasNext()) {
			System.out.println(itrg.next());
		}
		
		
		
	}
}
