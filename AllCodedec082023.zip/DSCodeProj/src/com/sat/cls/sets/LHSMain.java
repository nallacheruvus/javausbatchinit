package com.sat.cls.sets;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LHSMain {
	public static void main(String[] args) {
		LinkedHashSet<Integer> lhsa=new LinkedHashSet<Integer>();
		int[] arr1= {1,1,1,1,2,2,2,5,5,5,5,3,3,4,4,9,9,7,7};
		for(int a:arr1) {
			lhsa.add(a);
		}
		Iterator<Integer> itra=lhsa.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next()); 
		}
		double[] arr2= {1.2,1.2,3.2,3.2,5.4,5.4,0.1,0.1};
		LinkedHashSet<Double> lhsb=new LinkedHashSet<Double>();
		for(double d:arr2) {
			lhsb.add(d);
		}
		Iterator itrb=lhsb.iterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}
		char[] arr3= {'a','e','e','u','u','e','i','i'};
		LinkedHashSet<Character> lhsc=new LinkedHashSet<Character>();
		for(char c:arr3) {
			lhsc.add(c);
		}
		Iterator<Character> itrc=lhsc.iterator();
		while(itrc.hasNext()) {
			System.out.println(itrc.next());
		}
		LinkedHashSet<String> lhsd=new LinkedHashSet<String>();
		String[] arr5= {"Satish","satish","Sakshi","sakshi","junaid","abbas","abbas","lily","lily"};
		for(String j:arr5) {
			lhsd.add(j.toLowerCase());
		}
		Iterator<String> itrd=lhsd.iterator();
		while(itrd.hasNext()) {
			System.out.println(itrd.next());
		}
		
		String a="Satish";
		String b="satish";
		if(a.equalsIgnoreCase(b)) {
			System.out.println("Same");
		}
		LinkedHashSet<Float> hsb=new LinkedHashSet<Float>();
		float[] arr21= {88,88,1.1f,2.1f,2.1f,5.4f,7.66666f,7.66666f,7.66666f,7.66666f,66};
		for(float f:arr21) {
			hsb.add(f);
		}
		for(Object o:hsb) {
			System.out.println(o);
		}
		
		
		
	}

}
