package com.sat.stk;

import java.util.Stack;

public class StkMainCls {
	public static void main(String[] args) {
		Stack stk=new Stack();
		String[] arr= {"Einstein","Newton","Raman","Bhaskaracharya","Varahimihira"};
		for(String j:arr) {
			stk.push(j);//add elements to stk
		}//LIFO
		while(stk.size()>0) {
			System.out.println(stk.pop());//remove elements from stk
		}
		System.out.println(stk.size());//Tower of Hanoi=Stack
	}
}
