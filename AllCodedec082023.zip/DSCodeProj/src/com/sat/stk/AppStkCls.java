package com.sat.stk;

import java.util.Stack;

public class AppStkCls {
	public static void main(String[] args) {
		Stack stk=new Stack();
		String myStr="There are times when I wish I were in New York";
		char[] arr=myStr.toCharArray();
		for(char c:arr) {
			stk.push(c);
		}
		
		while(stk.size()>0) {
			System.out.print(stk.pop());
		}
		System.out.println();
				
		
		
		
	}
}
