package com.sat.stk;

import java.util.ArrayList;
import java.util.Scanner;

public class MyCls {
	public static void main(String[] args) {
		String ans = "y";
		Scanner scan = new Scanner(System.in);
		ArrayList myList = new ArrayList();
		while (ans.equals("y")) {//Sentinel Controlled Loop
			System.out.println("Please enter the name  of the contestant");
			String u = scan.nextLine();
			myList.add(u);
			System.out.println("If you want to enter next name type y");
			ans = scan.nextLine();
		}
		System.out.println("The list of contestentants is as follows:");
		for (Object a : myList) {
			System.out.println(a);
		}
	}
}
