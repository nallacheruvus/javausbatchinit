package com.sat.stk;

import java.util.Vector;

public class VecCls {
	public static void main(String[] args) {
		Vector vec=new Vector();
		String[] arr= {"Juniper","Cisco","Amaya","Attbell","Amritel"};
		for(String j:arr) {
			vec.add(j);
		}
		vec.add(21);
//		vec.add(true);
//		vec.add("hyderabad".getBytes());
		for(Object a:vec) {
			System.out.println(a);
		}
		
	}
}
