package com.sat.stk;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Stack;
import java.util.Vector;

public class ArrLstCls {
	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		int[] arr= {1,2,3,4,5,6,7,8,9,10};
		for(int i:arr) {
			al.add(i);
		}
		for(Object a:al) {
			System.out.println(a);
		}
		//
		ArrayList vec=new ArrayList();
		String[] arr2= {"Juniper","Cisco","Amaya","Attbell","Amritel"};
		for(String j:arr2) {
			vec.add(j);
		}
		vec.add(21);
//		vec.add(true);
//		vec.add("hyderabad".getBytes());
		for(Object a:vec) {
			System.out.println(a);
		}
	}
}
