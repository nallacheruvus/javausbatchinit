package com.sat.nonlin;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;

public class CarsMain {
	public static void main(String[] args) {
		Hashtable<Character, Cars> htcars = new Hashtable<Character, Cars>();
		char[] arr1 = { 'c', 's', 'i', 'l', 'j' };
		int[] arr2 = { 501, 201, 301, 401, 101 };
		String[] arr3 = { "Octavio", "Punto", "Lilac", "EClass", "Camry" };
		String[] arr4 = { "Skoda", "Fiat", "Cadillac", "Mercedes", "Toyota" };
		for (int i = 0; i < arr4.length; i++) {
			Cars cc = new Cars(arr2[i], arr3[i], arr4[i]);
			htcars.put(arr1[i], cc);
		}
		Iterator<Entry<Character, Cars>> cItr = htcars.entrySet().iterator();
		while (cItr.hasNext()) {
			Entry<Character, Cars> ent = (Entry<Character, Cars>) cItr.next();
			System.out.println(ent.getKey() + " " + ent.getValue().toString());
		}
	}
}
