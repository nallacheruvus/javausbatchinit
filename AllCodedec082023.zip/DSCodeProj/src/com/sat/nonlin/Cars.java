package com.sat.nonlin;

public class Cars {
	private int cid;
	private String cname;
	private String cbrand;

	public Cars() {
	}

	public Cars(int a, String b, String c) {
		this.cid = a;
		this.cname = b;
		this.cbrand = c;
	}

	@Override
	public String toString() {
		String fin = String.format("ID:%d\tName:%s\tBrand:%s", this.cid, this.cname, this.cbrand);
		return fin;
	}
}
