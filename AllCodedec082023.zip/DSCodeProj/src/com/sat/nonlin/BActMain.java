package com.sat.nonlin;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;

public class BActMain {
	public static void main(String[] args) {
		Hashtable<Integer, BankAccount> hbanac=new Hashtable<Integer, BankAccount>();
		int[] arr1= {11,12,13,14,15};
		String[] arr2= {"HSBC","HDFC","HDB","Lloyds","RBS"};
		String[] arr3= {"Jo Hun","Swati Mitra","Ali Asgar","Robert Percupolis","James Webb"};
		for (int i = 0; i < arr3.length; i++) {
			BankAccount act=new BankAccount(arr1[i],arr2[i],arr3[i]);
			hbanac.put(arr1[i], act);
		}
		Iterator<Entry<Integer,BankAccount>> itrBact=hbanac.entrySet().iterator();
		System.out.println("ID BID BName ActName");
		while(itrBact.hasNext()) {
			Entry<Integer,BankAccount> ent=(Entry<Integer,BankAccount>)itrBact.next();
			System.out.println(ent.getKey()+" "+ent.getValue().toString());
			System.out.println();
		}
		
		
		
		
	}
}
