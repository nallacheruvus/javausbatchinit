package com.sat.nonlin;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class MnClsHT {
	public static void main(String[] args) {
		int[] arr1= {1,2,4,5,66,7,8,9,10};
		String[] arr2= {"Juniper","Avaya","Cisco","Maya","Att","Sprint","Bell","Cross Stich","Jumper Suites"};
		Hashtable<Integer, String> hta=new Hashtable<Integer, String>();
		for (int i = 0; i < arr2.length; i++) {
			hta.put(arr1[i], arr2[i]);
		}
//		Iterator itr=hta.entrySet().iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
		//keys returns enumerator asIterator would convert it into iterator
//		Iterator itrb=hta.keys().asIterator();
//		while(itrb.hasNext()) {
//			Object aa=itrb.next();
//			System.out.println(aa+" "+hta.get(aa));
//		}
		List l= Arrays.asList(hta.entrySet());
		for(Object a:l) {
			System.out.println(a);
		}
		Hashtable<Double, String> htb=new Hashtable<Double, String>();
		double[] arr3= {21.222,32.333,87.8888,98.9999,87.8888};
		String arr4[]= {"Saigon","Budapest","Lima","Petersberg","Bombay"};
		for (int i = 0; i < arr4.length; i++) {
			htb.put(arr3[i], arr4[i]);
		}
		Set set=htb.entrySet();
		for(Object a:set) {
			System.out.println(a);
		}
		
		
		
		
	}
}
