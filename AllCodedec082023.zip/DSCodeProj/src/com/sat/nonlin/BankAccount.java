package com.sat.nonlin;

public class BankAccount {
	private int bid;
	private String bname;
	private String aname;
	public BankAccount() {
	}
	public BankAccount(int a,String b,String c) {
		this.bid=a;
		this.bname=b;
		this.aname=c;
	}
	@Override
	public String toString() {
		return this.bid+" "+this.bname+" "+this.aname;
	}
}
