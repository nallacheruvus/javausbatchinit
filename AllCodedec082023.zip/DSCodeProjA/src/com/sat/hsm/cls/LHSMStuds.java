package com.sat.hsm.cls;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

public class LHSMStuds {
	public static void main(String[] args) {
		int[] arr1= {21,12,31,14,51};
		String[] arr2= {"Rama","Devesh","Snighdha","Jeevan","Ali"};
		String[] arr3= {"Rama@yahoo.com","Devesh@yahoo.com","Snighdha@yahoo.com","Jeevan@yahoo.com","Ali@yahoo.com"};
		LinkedHashMap<Integer, Student> lhms=new LinkedHashMap<Integer, Student>();
		for (int i = 0; i < arr3.length; i++) {
			Student std=new Student();
			std.setSid(arr1[i]);
			std.setSname(arr2[i]);
			std.setSemail(arr3[i]);
			lhms.put(arr1[i]*13, std);
		}
//		Iterator<Entry<Integer, Student>> itr=lhms.entrySet().iterator();
//		while(itr.hasNext()) {
//			Entry<Integer, Student> ent=(Entry<Integer, Student>)itr.next();
//			System.out.println("---".repeat(20));
//			System.out.println("Recordid:"+ent.getKey()+"\n"+ent.getValue());
//			System.out.println("---".repeat(20));
//		}
		
//		Set set=lhms.entrySet();
//		for(Object a:set) {
//			Entry<Integer, Student> ent=(Entry<Integer, Student>)a;
//			System.out.println("---".repeat(20));
//			System.out.println("RecordID:"+ent.getKey()+"\n"+ent.getValue());
//			System.out.println("---".repeat(20));
//		}
		Set set=lhms.keySet();
		Iterator itra=set.iterator();
		while(itra.hasNext()) {
			int a=Integer.valueOf(itra.next().toString());
			System.out.println("___".repeat(20));
			System.out.println("Recordid:"+a+"\n"+lhms.get(a));
			System.out.println("___".repeat(20));
		}
	}
}
