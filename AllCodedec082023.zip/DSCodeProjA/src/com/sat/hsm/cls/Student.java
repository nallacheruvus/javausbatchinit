package com.sat.hsm.cls;

public class Student {
	private int sid;
	private String sname;
	private String semail;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	
	@Override
	public String toString() {
		String fin=String.format("ID:%d\nName:%s\nEmail:%s\n", this.sid,this.sname,this.semail);
		return fin;
	}
	
}
