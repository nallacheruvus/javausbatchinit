package com.sat.hsm.cls;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class HSMCls {
	public static void main(String[] args) {
		HashMap<Integer, String> hms=new HashMap<Integer, String>();
		int[] arr1= {21,12,31,14,51};
		String[] arr2= {"Physics","Chemistry","Nuclear Physics","Linux","Silicon Graphics"};
		for (int i = 0; i < arr2.length; i++) {
			hms.put(arr1[i], arr2[i]);
		}
//		System.out.println(hms);
		Iterator itr=hms.entrySet().iterator();
		while(itr.hasNext()) {
			Entry<Integer, String> ent=(Entry<Integer, String>)itr.next();
			System.out.println(ent.getKey()+" "+ent.getValue());
		}
		HashMap<Integer, Double> hma=new HashMap<Integer, Double>();
		double[] arr3=new double[5];
		for (int i = 0; i < arr3.length; i++) {
			arr3[i]=Math.sqrt(arr1[i]);
		}
		for (int i = 0; i < arr3.length; i++) {
			hma.put(arr1[i], arr3[i]);
		}
		Iterator itrb=hma.entrySet().iterator();
		while(itrb.hasNext()) {
			Entry<Integer, Double> ent=(Entry<Integer, Double>)itrb.next();
			System.out.println(ent.getKey()+" "+ent.getValue());
		}

		Student std=new Student();
		std.setSid(1001);
		std.setSname("Manik Prabhu");
		std.setSemail("manik@yahoo.com");
		System.out.println(std);
		
		
		
	}
}
