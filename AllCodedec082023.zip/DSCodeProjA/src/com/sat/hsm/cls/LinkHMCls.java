package com.sat.hsm.cls;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class LinkHMCls {
	public static void main(String[] args) {
		LinkedHashMap<Integer, String> lhm=new LinkedHashMap<Integer, String>();
		int[] arr1= {21,12,31,14,51};
		String[] arr2= {"Physics","Chemistry","Nuclear Physics","Linux","Silicon Graphics"};
		for (int i = 0; i < arr2.length; i++) {
			lhm.put(arr1[i], arr2[i]);
		}
		Iterator<Entry<Integer, String>> itr=lhm.entrySet().iterator();
		while(itr.hasNext()) {
			Entry<Integer, String> ent=(Entry<Integer, String>)itr.next();
			System.out.println(ent.getKey()+" "+ent.getValue());
		}
	}
}
