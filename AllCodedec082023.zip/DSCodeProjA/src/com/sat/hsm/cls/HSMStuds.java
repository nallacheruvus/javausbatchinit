package com.sat.hsm.cls;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HSMStuds {
	public static void main(String[] args) {
		HashMap<Integer, Student> hmstud=new HashMap<Integer, Student>();
		int[] arr1= {21,12,31,14,51};
		String[] arr2= {"Rama","Devesh","Snighdha","Jeevan","Ali"};
		String[] arr3= {"Rama@yahoo.com","Devesh@yahoo.com","Snighdha@yahoo.com","Jeevan@yahoo.com","Ali@yahoo.com"};
		for (int i = 0; i < arr3.length; i++) {
			Student std=new Student();
			std.setSid(arr1[i]);
			std.setSname(arr2[i]);
			std.setSemail(arr3[i]);
			hmstud.put(arr1[i]+100, std);
		}
//		Iterator<Entry<Integer, Student>> itrs=hmstud.entrySet().iterator();
//		while(itrs.hasNext()) {
//			Entry<Integer, Student> ent=(Entry<Integer, Student>)itrs.next();
//			System.out.println("***".repeat(20));
//			System.out.println("RecordID:"+ent.getKey()+"\n"+ent.getValue());
//			System.out.println("***".repeat(20));
//		}
//		Iterator itrk=hmstud.keySet().iterator();
//		while(itrk.hasNext()) {
//			int a=Integer.valueOf(itrk.next().toString());
//			System.out.println("___".repeat(20));
//			System.out.println("RecordID:"+a+"\n"+hmstud.get(a));
//			System.out.println("___".repeat(20));
//		}	
		
		
//		Set set=hmstud.entrySet();
//		for(Object a:set) {
//			Entry<Integer, Student> ent=(Entry<Integer, Student>)a;
//			System.out.println("RecordID:-"+ent.getKey()+"\nStudent Details\n"+ent.getValue());
//		}
		
		Set seta=hmstud.keySet();
		for(Object a:seta) {
			int b=Integer.valueOf(a.toString());
			System.out.println("---".repeat(20));
			System.out.println("RecordID:"+b+"\n"+hmstud.get(a));
			System.out.println("---".repeat(20));
		}
	}
}
