package com.sat.cls.hst;

public class Person {
	public Person(int a,String b,String c) {
		this.pid=a;
		this.pname=b;
		this.pemail=c;
	}
	private int pid;
	private String pname;
	private String pemail;
	@Override
	public String toString() {
		String fin=String.format("ID:%d\tName:%s\tEmail:%s", this.pid,this.pname,this.pemail);
		return fin;
	}
}
