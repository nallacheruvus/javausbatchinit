package com.sat.cls.hst;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class MnClsHst {
	public static void main(String[] args) {
		Hashtable<Integer, String> hts=new Hashtable<Integer, String>();
		int[] arr1= {301,101,2001,501,401};
		String[] arr2= {"Krishna","Kanha","Tulasi","Radhika","Raseswari"};
		for (int i = 0; i < arr2.length; i++) {
			hts.put(arr1[i], arr2[i]);
		}
		//1
//		Iterator it= hts.entrySet().iterator();
//		while(it.hasNext()) {
//			Entry<Integer, String> et=(Entry<Integer, String>)it.next();
//			System.out.println(et.getKey()+" "+et.getValue());
//		}
		//2
//		Set set=hts.entrySet();
//		for(Object a:set) {
//			System.out.println(a);
//		}
		//3
//		Iterator itra= hts.keys().asIterator();
//		while(itra.hasNext()) {
//			int k=(Integer)itra.next();
//			System.out.println(k+" "+hts.get(k));
//		}
		//4
		List arr=Arrays.asList(hts.entrySet());
		for(Object a:arr) {
			System.out.println(a);
		}
		
		Hashtable<String, String> htsb=new Hashtable<String, String>();
		String[] arr3= {"Tulsi","Surdas","Kabirdas","Aulia","Khusro"};
		for (int i = 0; i < arr3.length; i++) {
			htsb.put(arr2[i], arr3[i]);
		}
		//5
		Iterator<Entry<String, String>> itrb=htsb.entrySet().iterator();
		while(itrb.hasNext()) {
			Entry<String, String> ent=(Entry<String, String>)itrb.next();
			System.out.println(ent.getKey()+" "+ent.getValue());
		}
		
	}
}
