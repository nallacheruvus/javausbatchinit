package com.sat.cls.hst;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class MnClsA {
	public static void main(String[] args) {
		int[] arr1= {11,12,13,14,15};
		String[] arr2= {"Pankaj Kapoor","Praveen dehlavi","Ali Akbar","Jubaida Khannum","Robert Rodriguez"};
		String[] arr3=  {"Pankaj@yahoo.com","Praveen@yahoo.com","Ali@yahoo.com","Jubaida@yahoo.com","Robert@yahoo.com"};
		Hashtable<Integer, Person> htsp=new Hashtable<Integer, Person>();
		for (int i = 0; i < arr3.length; i++) {
			Person ps=new Person(arr1[i], arr2[i], arr3[i]);
			htsp.put(arr1[i], ps);
		}
		//1
//		Set<Entry<Integer, Person>> pHtSet=htsp.entrySet();
//		for(Entry<Integer, Person> ent:pHtSet) {
//			System.out.println(ent.getKey()+"\n"+ent.getValue()+"\n\n");
//		}
		//2
//		Iterator itra=htsp.keys().asIterator();
//		while(itra.hasNext()) {
//			int k=(Integer)itra.next();
//			Person p=(Person)htsp.get(k);
//			System.err.println(k);
//			System.out.println(p);
//		}
		//3
		Object[] arr=htsp.entrySet().toArray();
//		for(Object a:arr) {
//			Entry<Integer, Person> ent=(Entry<Integer,Person>)a;
//			System.out.println(ent.getKey()+"\n\n"+ent.getValue());
//			System.out.println("***".repeat(20));
//		}
		//4
//			System.out.println(Arrays.asList(htsp));
//			String j=Arrays.deepToString(arr);
//			System.out.println(j);
		//5
		List ls=Arrays.asList(arr);
//		for(Object a:ls) {
//			System.out.println(a);
//		}
		//6
//		Iterator itrb=ls.listIterator();
//		while(itrb.hasNext()) {
//			System.out.println(itrb.next());
//		}
		//7
		Object[] oArr=new Object[ls.size()];
		ls.toArray(oArr);
		for(Object a:oArr) {
			System.out.println(a);
		}
	}
}
