package com.sat.cls.stk;

import java.util.HashSet;
import java.util.Iterator;

public class SetSamp {
	public static void main(String[] args) {
		int[] arra= {11,11,11,11,1,2,2,2,2,3,3,3,3,4,44,44,4,4,4,4,4,55,5,5,5,5,6,6};
		HashSet<Integer> hsa=new HashSet<Integer>();
		for(int a:arra) {
			hsa.add(a);
		}
		System.out.println(hsa);
		double[] arrb= {12.2222,12.2222,12.2222,12.33333,12.33333,7.7,7.7,8.9,8.9};
		HashSet<Double> hsb=new HashSet<Double>();
		for(double d:arrb) {
			hsb.add(d);
		}
		System.out.println(hsb);
		float[] arrc= {1.1f,1.1f,2.1f,2.1f,3.1f,3.1f,5.4f,5.4f};
		HashSet<Float> hsc=new HashSet<Float>();
		for(float f:arrc) {
			hsc.add(f);
		}
		System.out.println(hsc);
		HashSet<Boolean> hsd=new HashSet<Boolean>();
		boolean[] arrd= {true,true,true,false,false,true,false};
		for(boolean b:arrd) {
			hsd.add(b);
		}
		System.out.println(hsd);
		HashSet<String> hse=new HashSet<String>();
		String[] arre= {"satish","satish","manish","manish","preetam","chunky","chunky","deepam","deepam"};
		for(String j:arre) {
			hse.add(j);
		}
		System.out.println(hse);
		HashSet<Character> hsf=new HashSet<Character>();
		char[] arrg= {'a','a','a','b','b','c','c','d','d','e','e','f','f'};
		for(char c:arrg) {
			hsf.add(c);
		}
		System.out.println(hsf);
		Iterator itra=hsa.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next());
		}
		Iterator itrb=hsb.iterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}
		Iterator itrc=hsc.iterator();
		while(itrc.hasNext()) {
			System.out.println(itrc.next());
		}
		Iterator itrd=hsd.iterator();
		while(itrd.hasNext()) {
			System.out.println(itrd.next());
		}	
	}
}
