package com.sat.cls.stk;

import java.util.LinkedHashSet;

public class LiSetSamp {
	public static void main(String[] args) {
			int[] arr1= {1,1,11,1,2,21,2,3,31,3,3,41,4,5,6,7,18,8,8,9,9};
			LinkedHashSet<Integer> lhsa=new LinkedHashSet<Integer>();
			for(int i:arr1) {
				lhsa.add(i);
			}
			System.out.println(lhsa);
			float[] arr2= {11.1f,1.1f,21.1f,21.1f,2.1f,3.1f,3.1f,3.1f};
			LinkedHashSet<Float> lhsb=new LinkedHashSet<Float>();
			for(float r:arr2) {
				lhsb.add(r);
			}
			System.out.println(lhsb);
			double[] arr3= {122.1,12.1,12.1,13.2,13.2,14.1,14.1,15.1,15.1};
			LinkedHashSet<Double> lhsc=new LinkedHashSet<Double>();
			for(double d:arr3) {
				lhsc.add(d);
			}
			System.out.println(lhsc);
			char[] arr4= {'a','a','a','a','b','b','b','c','c','d','d','d'};
			LinkedHashSet<Character> lhsd=new LinkedHashSet<Character>();
			for(char c:arr4) {
				lhsd.add(c);
			}
			System.out.println(lhsd);
			boolean[] arr5= {true,true,false,false,false};
			LinkedHashSet<Boolean> lhb=new LinkedHashSet<Boolean>();
			for(boolean b:arr5) {
				lhb.add(b);
			}
			System.out.println(lhb);
	}
}
