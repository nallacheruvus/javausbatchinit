package com.sat.cls.stk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.Vector;

public class StkIter {
	public static void main(String[] args) {
		Stack<Integer> sth=new Stack<Integer>();
		int[] arr= {11,12,13,14,15};
		for(int i:arr) {
			sth.push(i);
		}
		Iterator itr=sth.iterator();
		while(itr.hasNext()) {
			System.out.println(sth.pop());
		}
		System.out.println("*".repeat(10));
		Vector<Float> vefc=new Vector<Float>();
		float[] arr2= {12.22222f,21.22222f,43.4444f,54.5555f,65.66666f};
		for(float f:arr2) {
			vefc.add(f);
		}
		Iterator<Float> itrf=vefc.iterator();
		while(itrf.hasNext()) {
			System.out.println(itrf.next());
		}
		System.out.println("*".repeat(10));
		String[] arrd= {"Ramanujam","Bose","Gauss","Einstein","Raman"};
		List al=Arrays.asList(arrd);
		Iterator itra=al.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next().toString().toUpperCase());
		}
		Integer[] arre= {102,203,403,504,805};
		List ali=Arrays.asList(arre);
		Iterator itrb=ali.iterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}
		Double[] arrf= {21.88848484,32.333333,43.44444,54.55555,65.666666};
		List ald=Arrays.asList(arrf);
		Iterator itrd=ald.iterator();
		while(itrd.hasNext()) {
			System.out.println(itrd.next());
		}
		List ale=Arrays.asList(new String[]{"Sunrisers","Palmi","James","Sunk","Respo"});
		Iterator itre=ale.iterator();
		while(itre.hasNext()) {
			System.out.println(itre.next());
		}
		
	}
}
