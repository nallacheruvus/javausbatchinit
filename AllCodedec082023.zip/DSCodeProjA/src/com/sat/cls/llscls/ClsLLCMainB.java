package com.sat.cls.llscls;

import java.util.Iterator;
import java.util.LinkedList;

public class ClsLLCMainB {
	public static void main(String[] args) {
		LinkedList<Integer> lli=new LinkedList<Integer>();
		int[] arr= {101,201,301,401,501};
		for(int i:arr) {
//			lli.add(i);
//			lli.addLast(i);
			lli.addFirst(i);
		}
		Iterator itra=lli.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next());
		}
		LinkedList<String> lls=new LinkedList<String>();
		String[] arra= {"Jait","Kosi kalan","Bhuteshwar","Goverdhan chauraha"};
		for(String j:arra) {
//			lls.add(j);
//			lls.addFirst(j);
			lls.addLast(j);
		}
		Iterator itrb=lls.iterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}
		LinkedList<Character> llc=new LinkedList<>();
		char[] arrb= {'a','b','c','i','j'};
		for(char c:arrb) {
//			llc.add(c);
//			llc.addFirst(c);
			llc.addLast(c);
		}
		Iterator<Character> itrc=llc.iterator();
		while(itrc.hasNext()) {
			System.out.println(itrc.next());
		}
		LinkedList<Boolean> llb=new LinkedList<Boolean>();
		boolean[] arrd= {true,true,false,false,true};
		for(boolean b:arrd) {
			llb.add(b);
		}
		Iterator<Boolean> itrd=llb.iterator();
		while(itrd.hasNext()) {
			System.out.println(itrd.next());
		}
	}
}
