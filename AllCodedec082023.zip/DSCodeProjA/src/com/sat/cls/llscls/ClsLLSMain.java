package com.sat.cls.llscls;

import java.util.LinkedList;

public class ClsLLSMain {

	public static void main(String[] args) {
		LinkedList<Integer> li = new LinkedList<Integer>();
		int[] arr= {11,12,13,14,15};
		for(int i:arr) {
			li.add(i);
		}
		System.out.println(li);
		LinkedList<Float> lf=new LinkedList<Float>();
		float[] arr2= {12.33333f,54.55555f,65.6666f,76.7777f};
		for(float f:arr2) {
			lf.add(f);
		}
		System.out.println(lf);
		LinkedList<Double> ld=new LinkedList<Double>();
		double[] arr3= {32.333333,43.444444,65.66666666,76.77777};
		for(double d:arr3) {
			ld.add(d);//Boxing
		}
		System.out.println(ld);
		System.out.println(ld.getFirst());
		System.out.println(ld.getLast());
		for(Object o:ld) {
			System.out.println(o);//Unboxing
		}
	}

}
