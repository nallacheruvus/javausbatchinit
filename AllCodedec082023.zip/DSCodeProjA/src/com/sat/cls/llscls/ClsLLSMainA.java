package com.sat.cls.llscls;

import java.util.LinkedList;

public class ClsLLSMainA {
	public static void main(String[] args) {
		LinkedList<String> lls=new LinkedList<String>();
		String[] arr= {"Goverdhan","Brindavan","Chatikara","Chata","Barsana"};
		for(String j:arr ) {
//			lls.addFirst(j);//LIFO-Stack
			lls.addLast(j);//FIFO-Queue
		}
		System.out.println(lls);
		for(Object o:lls) {
			System.out.println(o);
		}
		LinkedList<Integer> lli=new LinkedList<Integer>();
		lli.add(31);
		lli.addFirst(41);
		lli.addLast(100);
		System.out.println(lli);
		LinkedList<Boolean> llb=new LinkedList<Boolean>();
		boolean[] barr= {true,true,true,false,false,true};
		for(boolean b:barr) {
			llb.addFirst(b);
		}
		LinkedList<Character> llc=new LinkedList<Character>();
		System.out.println(llb);
		char[] carr= {'a','e','i','o','u'};
		for(char c:carr) {
//			llc.addLast(c);
			llc.addFirst(c);
		}
		System.out.println(llc);
		
		System.out.println(llc.get(0));
//		System.out.println(llc.remove(0));
		
	}

}
