package com.sat.cls.tsa;

public class Cars {
	private int carid;
	public int getCarid() {
		return carid;
	}
	public void setCarid(int carid) {
		this.carid = carid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCbrand() {
		return cbrand;
	}
	public void setCbrand(String cbrand) {
		this.cbrand = cbrand;
	}
	private String cname;
	private String cbrand;
	@Override
	public String toString() {
		return "\n ID:".trim()+this.carid+"\nName:"+this.cname+"\nBrand"+this.cbrand;
	}
}
