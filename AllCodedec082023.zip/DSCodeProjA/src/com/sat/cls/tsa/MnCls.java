package com.sat.cls.tsa;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.TreeMap;

public class MnCls {
	public static void main(String[] args) {
		TreeMap<Integer, String> tmap=new TreeMap<Integer, String>();
		int[] arr1= {122,12,31,14,51};
		String[] arr2= {"Physics","Chemistry","Geology","Botany","Zoology"};
		for (int i = 0; i < arr2.length; i++) {
			tmap.put(arr1[i], arr2[i]);
		}
		System.out.println(tmap);
		TreeMap<Float, String> tmapa=new TreeMap<Float, String>();
		float[] arr3= {7.9f,2.1f,1.1f,5.3f,0.5f};
		for (int i = 0; i < arr3.length; i++) {
			tmapa.put(arr3[i], arr2[i]);
		}
		System.out.println(tmapa);
		TreeMap<Double, String> tmb=new TreeMap<Double, String>();
		double[] arr4= {7.933,2.19,1.4441,5.22223,0.22225};
		for (int i = 0; i < arr3.length; i++) {
			tmb.put(arr4[i], arr2[i]);
		}
//		System.out.println(tmb);
		Iterator itr=tmb.entrySet().iterator();
		while(itr.hasNext()) {
			Entry<Double, String> ent=(Entry<Double, String>)itr.next();
			System.out.println(ent.getKey()+" "+ent.getValue());
		}
		TreeMap<Character, String> tmc=new TreeMap<Character, String>();
		char[] arr5= {'u','o','e','i','a'};
		for (int i = 0; i < arr5.length; i++) {
			tmc.put(arr5[i], arr2[i]);
		}
		System.out.println(tmc);
		
		Cars cc=new Cars();
		cc.setCarid(111);
		cc.setCname("Octavio");
		cc.setCbrand("Skoda");
		System.out.println(cc);
		
		
	}
}