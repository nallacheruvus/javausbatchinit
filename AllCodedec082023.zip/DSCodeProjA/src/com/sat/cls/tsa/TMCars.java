package com.sat.cls.tsa;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

public class TMCars {
	public static void main(String[] args) {
		int[] arr1= {1001,2,79,1,33};
		String[] arr2= {"Punto","Octavio","Camry","Mark-2","Lilac"};
		String[] arr3= {"Fiat","Skoda","Toyota","Ambassador","Cadillac"};
		TreeMap<Integer, Cars> tmCars=new TreeMap<Integer, Cars>();
		for (int i = 0; i < arr3.length; i++) {
			Cars c=new Cars();
			c.setCarid(arr1[i]);
			c.setCname(arr2[i]);
			c.setCbrand(arr3[i]);
			tmCars.put(arr1[i]+100, c);
		}
//		System.out.println(tmCars);
//		Iterator<Entry<Integer, Cars>> iter=tmCars.entrySet().iterator();
//		while(iter.hasNext()) {
//			Entry<Integer, Cars> e=(Entry<Integer, Cars>)iter.next();
//			System.out.println("***".repeat(20));
//			System.out.println("Registration ID:"+e.getKey()+"\n"+e.getValue());
//			System.out.println("***".repeat(20));
//		}
//		Set set=tmCars.keySet();
//		for(Object a:set) {
//			System.out.println(a+" "+tmCars.get(a));
//		}
		Set ss=tmCars.entrySet();
		for(Object a:ss) {
			Entry<Integer, Cars> ent=(Entry<Integer, Cars>)a;
			System.out.println(ent.getKey()+" "+ent.getValue());
		}
	}
}
