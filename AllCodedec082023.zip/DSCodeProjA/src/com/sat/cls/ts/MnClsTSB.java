package com.sat.cls.ts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class MnClsTSB {
	public static void main(String[] args) {
		System.out.println("Printing the list of books");
		List<Books> ls=retBList();
//		Iterator itBooks=ls.iterator();
//		while(itBooks.hasNext()) {
//			Books b=(Books)itBooks.next();//Typecasting
//			String h=String.format("ID:%s\nName:%s\nAuthor:%s\n\n",b.getBid(),b.getBname(),b.getBauth() );
//			System.out.println(h);
//		}
		
//		ListIterator<Books> litb=ls.listIterator();
//		while(litb.hasNext()) {
//			Books b=(Books)litb.next();
//			System.out.println(b.getBid()+" "+b.getBname()+" "+b.getBauth());
//		}
//		System.out.println("_".repeat(30));
//		while(litb.hasPrevious()) {
//			Books b=(Books)litb.previous();
//			System.out.println(b.getBid()+" "+b.getBname()+" "+b.getBauth());
//		}
		
		List<Books> lsub= ls.subList(0, 3);
		for(Books a:lsub) {
			System.out.println(a.getBid()+" "+a.getBname()+" "+a.getBauth());
		}
		
		
		
	}
	
	public static List<Books> retBList(){
		List<Books> lb=new ArrayList<Books>();
		String[] arr1= {"1A","2B","3C","4D","5E"};
		String[] arr2= {"Ramayan","Mahabharat","Quiet flows of don","Pelican brief","Last sigh of moor"};
		String arr3[]= {"Valmiki","Ved Vyas","M Sholkov","John Grisham","Salman Rushdie"};
		for (int i = 0; i < arr3.length; i++) {
			Books b=new Books();
			b.setBid(arr1[i]);
			b.setBname(arr2[i]);
			b.setBauth(arr3[i]);
			lb.add(b);
		}
		return lb;
	}
}
