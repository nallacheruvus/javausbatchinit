package com.sat.cls.ts;

import java.util.Iterator;
import java.util.TreeSet;

public class MnClsTS {
	public static void main(String[] args) {
		TreeSet<Integer> tsa=new TreeSet<Integer>();
		int[] arr= {111,111,21,21,67,67,55,55,44,44,22,11,7,22};
		for(int i:arr) {
			tsa.add(i);
		}
//		Iterator<Integer> itr=tsa.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
//		Iterator<Integer> itra= tsa.descendingIterator();
//		while(itra.hasNext()) {
//			System.out.println(itra.next());
//		}
		float[] arr1= {111.3f,21.22f,1.1f,43.5f,87.88f,12.2f};
		TreeSet<Float> tsf=new TreeSet<Float>();
		for(float f:arr1) {
			tsf.add(f);
		}
//		Iterator<Float> itrb=tsf.iterator();
//		while(itrb.hasNext()) {
//			System.out.println(itrb.next());
//		}
//		Iterator<Float> itrc=tsf.descendingIterator();
//		while(itrc.hasNext()) {
//			System.out.println(itrc.next());
//		}
		TreeSet<Double> tsg=new TreeSet<Double>();
		double[] arr2= {21.2222,1.11,3.1,0.9,7.33,5.5};
		for(double d:arr2) {
			tsg.add(d);
		}
//		for(Object a:tsg) {
//			System.out.println(a);
//		}
		
		char[] arr3={'u','o','i','e','a','a','a','e','i','o','u'};
		TreeSet<Character> tsh=new TreeSet<Character>();
		for(char c:arr3) {
			tsh.add(c);
		}
//		for(Object a:tsh) {
//			System.out.println(a);
//		}
		Iterator<Character> itrd=tsh.iterator();
//		Iterator<Character> itrd=tsh.descendingIterator();
		while(itrd.hasNext()) {
			System.out.println(itrd.next());
		}
	}
}
