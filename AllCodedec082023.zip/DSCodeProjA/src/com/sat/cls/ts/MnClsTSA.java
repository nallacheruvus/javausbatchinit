package com.sat.cls.ts;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class MnClsTSA {
	public static void main(String[] args) {
		String[] arr= {"Geology","Geophysics","Geochemistry","Petrology","Metamorphosis"};
		List<String> ls=Arrays.asList(arr);
//		Iterator<String> itra=ls.iterator();
//		while(itra.hasNext()) {
//			System.out.println(itra.next());
//		}
		ListIterator<String> itrb= ls.listIterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}
		System.out.println("*".repeat(20));
		while(itrb.hasPrevious()) {
			System.out.println(itrb.previous());
		}
	}
}
