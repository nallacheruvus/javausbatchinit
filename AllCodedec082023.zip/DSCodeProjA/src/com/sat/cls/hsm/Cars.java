package com.sat.cls.hsm;

public class Cars {
	private int cid;
	private String cname;
	private String cbrand;
	
	public Cars(int a,String b,String c) {
		this.cid=a;
		this.cname=b;
		this.cbrand=c;
	}
	
	@Override
	public String toString() {
		String fin=String.format("CID:%d\nCar Name:%s\nCar Brand:%s", this.cid,this.cname,this.cbrand);
		return fin;
	}
}
