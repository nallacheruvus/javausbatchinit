package com.sat.cls.hsm;

import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class MyMapCls {
	public static void main(String[] args) {
		HashMap<Integer,String> hma=new HashMap<Integer, String>();
		int[] arr1= {101,12,1003,14,105};
		String[] arr2= {"Physics","Nuclear Physics","Geo Physics","Seisomology","Periscope"};
		for (int i = 0; i < arr2.length; i++) {
			hma.put(arr1[i], arr2[i]);
		}
		//1
//		Set set=hma.entrySet();
//		for(Object a:set) {
//			System.out.println(a);
//		}
		//2
//		Iterator<Entry<Integer, String>> itr=hma.entrySet().iterator();
//		while(itr.hasNext()) {
////			System.out.println(itr.next());
//			Entry<Integer, String> etr=(Entry<Integer,String>)itr.next();
//			System.out.println(etr.getKey()+" "+etr.getValue());
//		}
		//3
//		Set set=hma.keySet();
//		for(Object a:set) {
//			int k=Integer.valueOf(a.toString());
//			String b=hma.get(k);
//			System.out.println(k+" "+b);			
//		}
		//4
		Object[] arrb=Arrays.asList(hma.entrySet()).toArray();
//		for(Object a:arrb) {
//			System.out.println(a);
//		}
		//5
//		System.out.println(Arrays.deepToString(arrb));
		List<Set<Entry<Integer, String>>> ls=Arrays.asList(hma.entrySet());
		Iterator itrc=ls.listIterator();
		while(itrc.hasNext()) {
			System.out.println(itrc.next());
		}
		//6
		for(Object a:hma.entrySet().toArray()) {
			System.out.println(a);
		}
		//7
		Object[] arre=new Object[5];
		hma.entrySet().toArray(arre);
		for (int i = 0; i < arre.length; i++) {
			System.out.println(arre[i]);
		}
		HashMap<String, String> hmb=new HashMap<String, String>();
		String[] arrL= {"Soni","Madhu","Kaivalya","Neeraj","Pandulkar"};
		for (int i = 0; i < arrL.length; i++) {
			hmb.put(arr2[i], arrL[i]);
		}
		System.out.println(hmb);
		HashMap<Integer, Double> hmc=new HashMap<Integer, Double>();
		for (int i = 0; i < arrL.length; i++) {
			int j=i+1;
			hmc.put(j, Math.sqrt(j));
		}
		System.out.println(hmc);
		Collection em=hmc.values();
		System.out.println(em.toString());
		Cars c=new Cars(1002, "Punto", "Fiat");
		System.out.println(c);
	}
}