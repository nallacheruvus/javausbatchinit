package com.sat.cls.hsm;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

public class MyLHMCls {
	public static void main(String[] args) {
		int[] arr1= {1090,8765,2345,6578,9878};
		String[] arr2= {"Octavio","Punto","Camry","Continental","Thar"};
		LinkedHashMap<Integer, String> lhma=new LinkedHashMap<Integer, String>();
		for (int i = 0; i < arr2.length; i++) {
			lhma.put(arr1[i], arr2[i]);
		}
//		Iterator itra=lhma.entrySet().iterator();
//		while(itra.hasNext()) {
//			Entry<Integer, String> ent=(Entry<Integer, String>)itra.next();
//			System.out.println(ent.getKey()+" "+ent.getValue());
//		}
		
		Set set=lhma.entrySet();
		for(Object a:set) {
			Entry<Integer, String> ent=(Entry<Integer, String>)a;
			System.out.println(ent.getKey()+" "+ent.getValue());
		}
		
	}
}
