package com.sat.cls.hsm;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public class MyMapclsA {
	public static void main(String[] args) {
		int[] arr1= {1090,8765,2345,6578,9878};
		String[] arr2= {"Octavio","Punto","Camry","Continental","Thar"};
		String[] arr3= {"Skoda","Fiat","Toyota","Lincoln","Jeep"};
		Cars[] cArr=new Cars[5];
		for (int i = 0; i < cArr.length; i++) {
			Cars cc=new Cars(arr1[i],arr2[i],arr3[i]);
			cArr[i]=cc;
		}
		
		HashMap<Integer, Cars> hmCar=new HashMap<Integer, Cars>();
		for (int i = 0; i < cArr.length; i++) {
			hmCar.put(arr1[i]+100, cArr[i]);
		}
//		System.out.println(hmCar);
//		Iterator itra=hmCar.entrySet().iterator();
//		while(itra.hasNext()) {
//			Entry<Integer, Cars> ent=(Entry<Integer, Cars>)itra.next();
//			System.out.println(ent.getKey()+"\n"+ent.getValue());
//		}
		//Object oArr[]=Arrays.asList(hmCar.entrySet()).toArray();
//		for(Object a:oArr) {
//			System.out.println(a);
//		}

		Object[] arrb=hmCar.keySet().toArray();
//		for(Object aa:arrb) {
//			System.out.println(aa+"\n"+hmCar.get(aa));
//		}
		List ls=Arrays.asList(arrb);
		for(Object t:ls.toArray()) {
			System.out.println(t+"\n"+hmCar.get(t));
		}
	}
}
