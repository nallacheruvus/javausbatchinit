package com.sat.arrvec.cls;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrClsA {
	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		Scanner scan=new Scanner(System.in);
		String ans="y";
		while(ans.equals("y")) {
			System.out.println("Enter the name of the candidate");
			String nm=scan.nextLine();
			System.out.println("Enter email");
			String em=scan.nextLine();
			System.out.println("Enter Age");
			int age=Integer.parseInt(scan.nextLine());
			al.add(nm+" "+em+" "+age);
			System.out.println("Press y if you want to continue");
			ans=scan.nextLine().toLowerCase();
		}
		for(Object a:al) {
			System.out.println(a);
		}
	}
}
