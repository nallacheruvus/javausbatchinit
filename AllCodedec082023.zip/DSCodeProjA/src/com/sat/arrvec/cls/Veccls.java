package com.sat.arrvec.cls;

import java.util.Vector;

public class Veccls {
	public static void main(String[] args) {
		Vector vec=new Vector();
		String jj="hai there";
		String[] arr= {"Varahimihira","Aryabhatta","Nagarjuna","Bhaskaracharya","Kapila"};
		for(String j:arr) {
			vec.add(j);
		}
//		vec.add(21);
//		vec.add(true);
//		vec.add("My String".getBytes());
		for(Object a:vec) {
			System.out.println(a);
		}
//		int i=10;
//		Integer ii=new Integer(i);
//		ii=null;
		
		
	}
}
