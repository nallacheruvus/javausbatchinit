package com.sat.arrvec.cls;

import java.util.ArrayList;
import java.util.Vector;

public class Arrlistcls {
	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		int[] arr= {12,13,14,15,16,17,18,19,20,11};
		for(int i:arr) {
			al.add(i);
		}
//		al.add(109.747474747474747);
//		al.add(12.444444f);
		for(Object a:al) {
			System.out.println(Integer.valueOf(a.toString()));
		}
		ArrayList vec=new ArrayList();
		String jj="hai there";
		String[] arr2= {"Varahimihira","Aryabhatta","Nagarjuna","Bhaskaracharya","Kapila"};
		for(String j:arr2) {
			vec.add(j);
		}
//		vec.add(21);
//		vec.add(true);
//		vec.add("My String".getBytes());
		for(Object a:vec) {
			System.out.println(a);
		}
	}
}
