package com.sat.stk.cls;

import java.util.Stack;

public class StkClsB {
	public static void main(String[] args) {
		Stack stk=new Stack();
		String t="Join us on a brigade to combat insects and to kill them all";
		char[] arr=t.toCharArray();
		for(char c:arr) {
			stk.push(c);
		}
		while(stk.size()>0) {
			System.out.print(stk.pop());
		}
		System.out.println("\n"+stk.size());
	}
}
