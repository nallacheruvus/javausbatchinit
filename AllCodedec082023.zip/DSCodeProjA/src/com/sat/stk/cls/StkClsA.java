package com.sat.stk.cls;

import java.util.Stack;

public class StkClsA {
	public static void main(String[] args) {
		Stack stk=new Stack();
		String[] arr= {"Varahimihira","Kalidasa","Ramanujam","Linus Torvalds","Bhaskaracharya"};
		for (int i = 0; i < arr.length; i++) {
			stk.push(arr[i]);
		}
//		stk.push(1000);
//		stk.push('a');
//		stk.push(true);
		//LIFO
		while(stk.size()>0) {
			System.out.println(stk.pop());
		}
	}
}
