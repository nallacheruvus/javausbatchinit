package com.sat.llnk.cls;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class LLCMainB {
	public static void main(String[] args) {
		int[] arr= {21,32,43,54,65,76,87,98};
		LinkedList<Integer> li=new LinkedList<Integer>();
		for(int i:arr) {
//			li.add(i);
//			li.addFirst(i);
			li.addLast(i);
		}
		Iterator itr=li.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		float[] arr2= {21.22222f,32.33333f,43.444444f,54.55555f,65.66666f};
		LinkedList<Float> lf=new LinkedList<Float>();
		for(float ff:arr2) {
			lf.add(ff);
		}
		Iterator<Float> itra=lf.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next());
		}
		LinkedList<String> lsa=new LinkedList<String>();
		String[] arr21= {"Juniper","Amigos","Avaya","Rosalin","Nephron"};
		for(String j:arr21) {
//			lsa.add(j);
//			lsa.addFirst(j);
			lsa.addLast(j);
		}
		Iterator<String> itrb=lsa.iterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}
		
		
	}
}
