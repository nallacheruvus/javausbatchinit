package com.sat.llnk.cls;

import java.util.LinkedList;

public class LLClsMain {
	public static void main(String[] args) {
		//Generics
		LinkedList<Integer> li = new LinkedList<Integer>();
		int[] arr= {21,33,44,55,66,77,88};
		for(int a:arr) {
			li.add(a);
		}
		for(Object a:li) {
			System.out.println(a);
		}
		LinkedList<Float> lf=new LinkedList<Float>();
		lf.add(21.22222f);
		lf.add(76.66222f);
		lf.add(89.44442f);
		System.out.println(lf);
		LinkedList<Double> ld=new LinkedList<Double>();
		ld.add(21.222222);
		ld.add(98.999999990);
		ld.add(87.67676768);
		System.out.println(ld);
		LinkedList<Boolean> lb=new LinkedList<Boolean>();
		lb.add(true);
		lb.add(false);
		lb.add(true);
		System.out.println(lb);
		LinkedList<String> ls=new LinkedList<String>();
		ls.add("Sunidhi");
		ls.add("Sravya");
		ls.add("Kaivalya");
		System.out.println(ls);
	}
}
