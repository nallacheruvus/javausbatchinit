package com.sat.llnk.cls;

import java.util.Arrays;
import java.util.LinkedList;

public class LLClsMainA {
	public static void main(String[] args) {
		String[] arr= {"Joyse","Boron","Alexa","Jeevan","John"};
		LinkedList<String> ls=new LinkedList<String>();
		for(String j:arr) {
			ls.addFirst(j);//Stack//LIFO
		}
//		System.out.println(ls);
		for(Object o:ls) {
			System.out.println(o);
		}
		LinkedList<String> lsa=new LinkedList<String>();
		for(String j:arr) {
			lsa.addLast(j);//FIFO//Queue
		}
//		System.out.println(lsa);
		for(Object o:lsa) {
			System.out.println(o);
		}
		System.out.println("*".repeat(10));
		System.out.println(lsa.getFirst());
		System.out.println(lsa.getLast());
		System.out.println(ls.getFirst());
		System.out.println(ls.getLast());
		int ii=lsa.size();
		System.out.println("*".repeat(10));
		for (int i = 0; i < ii; i++) {
			System.out.println(lsa.get(i));
		}
	}
}
