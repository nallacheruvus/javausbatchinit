package com.sa.cls.tm;

public class BankAccount {
	private int bid;
	private String bname;
	private String baname;
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBaname() {
		return baname;
	}
	public void setBaname(String baname) {
		this.baname = baname;
	}
	@Override
	public String toString() {
		return "\nBID:"+this.bid+"\nBank Name:"+this.bname+"\nAccountholders Name:"+this.baname;
	}	
}
