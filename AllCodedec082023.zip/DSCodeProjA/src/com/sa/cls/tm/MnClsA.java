package com.sa.cls.tm;

import java.util.Arrays;
import java.util.TreeMap;

public class MnClsA {
	public static void main(String[] args) {
		TreeMap<Integer, String> tma=new TreeMap<Integer, String>();
		int[] arr1= {11,13,12,15,14};
		String[] arr2= {"Sandilya","Atri","Atreya","Jamadagni","Vyasa"};
		for (int i = 0; i < arr2.length; i++) {
			tma.put(arr1[i], arr2[i]);
		}
		System.out.println(tma);
		float[] arr3= {9.999f,2.2f,7.8f,5.4f,0.5f};
		TreeMap<Float, String> tmb=new TreeMap<Float, String>();
		for (int i = 0; i < arr3.length; i++) {
			tmb.put(arr3[i], arr2[i]);
		}
		double[] arr4= {9.999,2.2,7.8,5.4,0.5};
		TreeMap<Double, String> tmc=new TreeMap<Double, String>();
		for (int i = 0; i < arr4.length; i++) {
			tmc.put(arr4[i], arr2[i]);
		}
		System.out.println(tmc);
		char[] arr5= {'u','e','a','i','o'};
		TreeMap<Character, String> tmd=new TreeMap<Character, String>();
		for (int i = 0; i < arr5.length; i++) {
			tmd.put(arr5[i], arr2[i]);
		}
		System.out.println(tmb);
		System.out.println(tmd);
		BankAccount ba=new BankAccount();
		ba.setBid(1001);
		ba.setBname("Jamuna");
		ba.setBaname("Nivedita");
		System.out.println(ba);
	}
}