package com.sa.cls.tm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.Set;

public class BATMCls {
	public static void main(String[] args) {
		int[] arr1= {11,13,12,15,14};
		String[] arr3= {"HSBC","HDFC","ICICI","IDBI","HDB"};
		String[] arr2= {"Sandilya","Atri","Atreya","Jamadagni","Vyasa"};
		List<BankAccount> lba=new ArrayList<BankAccount>();
		for (int i = 0; i < arr2.length; i++) {
			BankAccount ba=new BankAccount();
			ba.setBid(arr1[i]);
			ba.setBname(arr3[i]);
			ba.setBaname(arr2[i]);
			lba.add(ba);
		}
		TreeMap<Integer, BankAccount> tmba=new TreeMap<Integer, BankAccount>();
		Iterator<BankAccount> iba=lba.iterator();
		int i=0;
		while(iba.hasNext()) {
			BankAccount ba=(BankAccount)iba.next();
			tmba.put(arr1[i]+100, ba);
			i++;
		}
//		System.out.println(tmba);
//		Iterator<Entry<Integer, BankAccount>> itr=tmba.entrySet().iterator();
//		while(itr.hasNext()) {
//			Entry<Integer, BankAccount> ent=(Entry<Integer, BankAccount>)itr.next();
//			System.out.println("****".repeat(20));
//			System.out.println("Registration ID:"+ent.getKey()+"\n"+ent.getValue());
//			System.out.println("****".repeat(20));
//		}
//		Set set=tmba.keySet();
//		for(Object a:set) {
//			int b=Integer.valueOf(a.toString());
//			System.out.println("****".repeat(20));
//			System.out.println("Registration ID:"+b+"\n"+tmba.get(b));
//			System.out.println("****".repeat(20));
//		}
		
		Object[] seta=tmba.entrySet().toArray();
//		System.out.println(Arrays.deepToString(seta));
		for(Object a:seta) {
			Entry<Integer, BankAccount> ent=(Entry<Integer, BankAccount>)a;
			System.out.println("****".repeat(20));
			System.out.println("Registration ID:"+ent.getKey()+"\n"+ent.getValue());
			System.out.println("****".repeat(20));
		}
	}

}
